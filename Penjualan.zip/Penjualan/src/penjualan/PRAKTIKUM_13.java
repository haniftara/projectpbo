/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package penjualan;

import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JRException;

/**
 *
 * @author muhba
 */
public class PRAKTIKUM_13 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
